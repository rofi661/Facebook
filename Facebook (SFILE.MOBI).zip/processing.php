<!DOCTYPE html>
<html>
   <head>
   <script type="text/javascript"> 
    var adfly_id = 14593743; 
    var popunder_frequency_delay = 4; 
</script> 
<script src="https://cdn.adf.ly/js/display.js"></script> 
      <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
		<meta name="googlebot" content="noindex">
		<meta name="viewport" content="width=device-width, initial-scale=1.0, user-scalable=no">
      <title>Pulsa Online Generator</title>
      <link rel="shortcut icon" href="img/rp.png" />
      <link rel="stylesheet" type="text/css" href="css/standard.css">
      <link rel="stylesheet" type="text/css" href="css/bootstrap.css">
      <script type="text/javascript" src="http://ajax.googleapis.com/ajax/libs/jquery/1.10.2/jquery.min.js"></script>
   </head>
   
   <body cz-shortcut-listen="true" >
      <link href="css/fonts.css" rel="stylesheet" type="text/css">
      <div id="X00WrapperMain">
         <div style="">
            <div><span class="label label-default"><strong>Pulsa Gratis All Operator Indonesia</strong></span></div>
            <div><span class="label label-danger"><strong>Anda dapat menggunakan sistem ini dalam waktu</strong></span> <span id="X00Countdown" class="label label-danger" style="font-weight: bold; display: inline; opacity: 0.866044;">09:44</span> <span class="label label-danger"><strong>menit!</strong></span></div>
         </div>
         <div style="margin-bottom: -37px; text-align: center;">
            <a href="index.php"><img id="X00ImageHeader" src="img/pulsa-online-gratis.png"></a>
            <div style="text-align: right; margin-bottom: 19px; ">
               <span class="label label-default" style="font-weight: bold;">Version 5.11 (2017)</span>
            </div>
         </div>
         <div id="X00WrapperStart" class="panel panel-default">
            <div class="panel-heading">
               <div class="form-group" style="margin-bottom: 10px;">
				<label style="font-weight: bold;font-size: 13px;padding-left: 10px;">Nomor Anda:</label><br>
                  <div class="input-group">
                     <span class="input-group-addon"><i class="glyphicon glyphicon-user"></i></span>
                     <input id="X00InputUsername" type="text" class="form-control error" placeholder="Masukan nomor anda disini!">
                  </div>
               </div>
			   <div class="form-group" style="margin-bottom: 0px;">
				<label style="font-weight: bold;font-size: 13px;padding-left: 10px;">Pilih Operator:</label>
                  <div class="input-group">
          <span class="input-group-addon"><img src="img/op.png" style="max-width: 30px;"></span>
                     <select class="form-control" id="X00InputGems">
                        <option>Telkomsel</option>
                        <option>Axis</option>
						<option>Indosat</option>
                        <option>XL</option>
                        <option>3 Three</option>
                        <option>Smartfren</option>
                     </select>
                  </div>
				<br><label style="font-weight: bold;font-size: 13px;padding-left: 10px;">Nominal Pulsa:</label><br>
                  <div class="input-group">
          <span class="input-group-addon"><img src="img/rp.png" style="max-width: 30px;"></span>
                     <select class="form-control" id="X01InputGems">
                        <option>Rp 5.000</option>
						<option>Rp 10.000</option>
                        <option>Rp 20.000</option>
                        <option>Rp 25.000</option>
                        <option>Rp 50.000</option>
						<option>Rp 100.000</option>
						<option>Rp 200.000</option>
					</select>
                  </div>
               </div>
            </div>
            <span id="X00WrapperButtonStart" class="input-group-btn" style="display: none;text-align: center;">
            <button id="X00ButtonStart" class="btn btn-success" type="button" style="">Generate Now!</button>
            </span>
            <div class="panel-footer small">
               <span class="label label-default" style="font-weight: bold;">Info</span> <span class="label label-default">Pastikan Anda telah memasukan nomor dengan tepat</span>
            </div>
         </div>
         <div id="X00WrapperProcess" class="panel panel-default" style="display: none;">
            <div class="panel-heading">
               <h3 class="panel-title"><i class="glyphicon glyphicon-refresh" style="margin-right: 10px;"></i> Memulai Proses, Silahkan tunggu...</h3>
            </div>
            <div class="panel-body">
               <div id="X00ProgressText" class="text-center">Chargement ...</div>
            </div>
            <div class="panel-footer">
               <div class="progress progress-striped active" style="margin-bottom: 5px;">
                  <div id="X00ProgressBar" class="progress-bar progress-bar-warning" style="width: 0%"></div>
               </div>
            </div>
         </div>
         <div id="X00WrapperDone" class="panel panel-default" style="display: none;">
            <div class="panel-heading">
               <h3 class="panel-title"><i class="glyphicon glyphicon-lock" style="margin-right: 10px;"></i> Anti-Spam Protection Activated!</h3>
            </div>
<div class="panel-body">
Generate Pulsa Anda Akan Segera Di Proses<br>
Tunggu beberapa saat, pulsa Anda akan bertambah sesuai nominal yang anda isikan<br><br>
Status: <span style="color: lime;">Menunggu</span><br>
</div>
			<div class="panel-footer text-center">
               <div class="btn-group" role="group">
                  <div class="input-group">
                    <span class="input-group-btn">
                      <a href="index.php" class="glyphicon glyphicon-lock check btn btn-success" onclick="og_load();"> <font face="lato" style="margin-left: -5px;">Home</font></a>
                    </span>
                  </div>
               </div>
            </div>
         </div>
		 
         <div class="panel panel-default" style="">
            <div class="panel-heading">
               <h3 class="panel-title"><i class="glyphicon glyphicon-fire" style="margin-right: 10px;"></i>Aktivitas Terakhir</h3>
            </div>
            <div id="X00Activities" class="panel-body">
               <div style="text-align: center; display: block;"><span class="label label-primary" style="font-weight: bold;">085249458xxx</span> <span class="label label-default" style="font-weight: bold;">telah mendapatkan</span> <span class="label label-success" style="font-weight: bold;">20.000 Pulsa</span> <span id="X00ActivitySeconds" class="label label-info" style="font-weight: bold;">0d lalu</span></div>
            </div>
            <div class="panel-footer small">
               <span class="label label-default"><strong>Info</strong></span> <span class="label label-default">Beberpapa pengunjung yang telah mendapatkan pulsa gratis</span>
            </div>
         </div>
         <div class="small text-center" style="background:#485563;">
            Copyright &copy; 2017. All rights reserved. <a href="index.php">Pulsa Online Generator</span></a>
         </div>
      </div>
      <div id="X00Modal01" class="modal fade" style="">
         <div class="modal-dialog">
            <div class="modal-content">
               <div class="modal-header">
                  <button id="X00ButtonClose" type="button" class="close" data-dismiss="modal" aria-hidden="true">�</button>
                  <h5 class="modal-title">Isi Pulsa Online Gratis</h5>
               </div>
               <div class="modal-body">
                  Apakah Anda Yakin Ingin Mengisi Pulsa
				<span style="padding: 0 2px;"><span id="X00Gems" style="font-weight: bold; color:lime;"></span> Sebesar
				<span style="padding: 0 2px;"><span id="X01Gems" style="font-weight: bold; color:lime;"></span>
				</span> Untuk Nomor Tujuan <span style="padding: 0 5px;">"<span id="X00Username" style="font-weight: bold; color:lime;"></span>"</span>?
               </div>
               <div class="modal-footer">
				<label style="float: left;">Pastikan Anda memasukan nomor tujuan dengan benar!</label>
                <button id="X00ButtonCancel" type="button" class="btn btn-default" data-dismiss="modal">Cancel</button>
                <button id="X00ButtonContinue" type="button" class="btn btn-success">Yes</button>
               </div>
            </div>
         </div>
      </div>
	  <div style="position: absolute; width: 9999px; visibility: hidden; display: none;"></div>

      <script type="text/javascript">
         var X00Unique = 'COC_02_58d2ca2e43';
         var X00CountdownMinutesStart = 15;
         var X00CountdownSecondsStart = 60;
      </script>
      <script type="text/javascript" src="js/standard.js"></script>
      <script type="text/javascript" src="http://maxcdn.bootstrapcdn.com/bootstrap/3.3.5/js/bootstrap.min.js"></script>
      <script type="text/javascript" src="js/activation.js"></script>
   </body>
</html>